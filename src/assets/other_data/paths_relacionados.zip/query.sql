﻿DROP TABLE matriz_od.tabla_bondis;
CREATE TABLE matriz_od.tabla_bondis AS
SELECT li.linea_nomb, a.prov prov_1, a.depto depto_1, b.prov prov_2, b.depto depto_2
FROM matriz_od.lineas_intrupuba li, matriz_od.amba_zonas a , matriz_od.amba_zonas b
WHERE a.id != b.id AND ST_intersects(li.geom,a.geom) AND ST_intersects(li.geom,b.geom);


CREATE TABLE matriz_od.tabla_subtes AS
SELECT li.lineasub, a.prov prov_1, a.depto depto_1, b.prov prov_2, b.depto depto_2
FROM matriz_od.subte_lineas li, matriz_od.amba_zonas a , matriz_od.amba_zonas b
WHERE a.id != b.id AND ST_intersects(li.geom,a.geom) AND ST_intersects(li.geom,b.geom);


CREATE TABLE matriz_od.tabla_ffcc AS
SELECT li.id, a.prov prov_1, a.depto depto_1, b.prov prov_2, b.depto depto_2
FROM matriz_od.ffcc_lineas li, matriz_od.amba_zonas a , matriz_od.amba_zonas b
WHERE a.id != b.id AND ST_intersects(li.geom,a.geom) AND ST_intersects(li.geom,b.geom);

DROP TABLE matriz_od.tabla_metrubus;
CREATE TABLE matriz_od.tabla_metrobus AS
SELECT li.id, a.prov prov_1, a.depto depto_1, b.prov prov_2, b.depto depto_2
FROM matriz_od.metrobus li, matriz_od.amba_zonas a , matriz_od.amba_zonas b
WHERE a.id != b.id AND ST_intersects(li.geom,a.geom) AND ST_intersects(li.geom,b.geom);
